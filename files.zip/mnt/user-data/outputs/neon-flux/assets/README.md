# Assets

NEON FLUX needs no external assets. All graphics are drawn procedurally on Canvas and all sound effects are generated with the Web Audio API. Put any extra original assets here if you add them later.
